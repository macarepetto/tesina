#include "Physical_Event_Module.h"

bool PhysicalEventModule::begin(int pin) {
    if (started_) return true;
    if (!counter_.started()) return false;
    pinMode(pin, INPUT_PULLUP);
    attachInterruptArg(uint8_t(pin), &PhysicalEventModule::router,
                       this, FALLING);
    started_ = true;
    return true;
}

void IRAM_ATTR PhysicalEventModule::router(void* arg) {
    static_cast<PhysicalEventModule*>(arg)->onInterrupt();
}

void IRAM_ATTR PhysicalEventModule::onInterrupt() {
    const uint32_t at_us = micros();
    // Solo se acepta una pulsacion por cada 120 ms, igual que antes.
    if (total_ && uint32_t(at_us - last_event_us_) < DEBOUNCE_US) return;
    const uint64_t ticks = ticksAtInterrupt();

    portENTER_CRITICAL_ISR(&mux_);
    // Solo esta ISR modifica total_ y last_event_us_.
    ++total_;
    last_event_us_ = at_us;
    if (count_ < CAPACITY) {
        const uint8_t slot = uint8_t((head_ + count_) % CAPACITY);
        pending_[slot].ticks = ticks;
        pending_[slot].event_us = at_us;
        pending_[slot].number = total_;
        pending_[slot].discarded = discarded_;
        ++count_;
    } else {
        ++discarded_;
    }
    portEXIT_CRITICAL_ISR(&mux_);
}

bool PhysicalEventModule::consume(PhysicalEventSample& out) {
    portENTER_CRITICAL(&mux_);
    const bool available = count_ != 0;
    if (available) {
        out = pending_[head_];
        out.discarded = discarded_; // Contabiliza tambien descartes posteriores.
        head_ = uint8_t((head_ + 1) % CAPACITY);
        --count_;
    }
    portEXIT_CRITICAL(&mux_);
    return available;
}
