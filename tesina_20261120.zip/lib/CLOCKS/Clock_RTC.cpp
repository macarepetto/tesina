#include "Clock_RTC.h"

bool ClockRTC::update() {
    TickEdgeSample sample;
    if (!sqw_.consume(sample)) return false;

    // Conservar la referencia anterior solo para validar continuidad.
    // Un nuevo flanco invalida el anclaje hasta que se lea su calendario.
    const bool habia_referencia = has_reference_;
    has_reference_ = false;
    if (!sample.valid || sample.seq == 0 || sample.pending != 1 ||
        uint32_t(micros() - sample.at_us) > 250000UL) {
        return false;
    }

    int64_t epoch_seconds = 0;
    if (!rtc_.readEpoch(epoch_seconds) || epoch_seconds <= 0) {
        return false;
    }

    // Comprobar que no llegó otro SQW durante la operación I2C.
    TickEdgeSample latest;
    if (!sqw_.peek(latest) || latest.seq != sample.seq ||
        latest.ticks != sample.ticks ||
        uint32_t(micros() - sample.at_us) > 250000UL) {
        return false;
    }

    // Validaciones recuperadas de RTC_SQW_Clock_Module:
    // solo entre dos SQW consecutivos con referencias validas.
    if (habia_referencia && sample.seq == ref_seq_ + 1) {
        if (epoch_seconds != ref_time_us_ / 1000000LL + 1LL) {
            return false;
        }
        if (sample.ticks < ref_ticks_) {
            return false;
        }
        const uint64_t ticks_entre_sqw = sample.ticks - ref_ticks_;
        if (ticks_entre_sqw < TICKS_PER_SECOND - 10ULL ||
            ticks_entre_sqw > TICKS_PER_SECOND + 10ULL) {
            return false;
        }
    }

    ref_seq_ = sample.seq;
    ref_ticks_ = sample.ticks;
    ref_time_us_ = epoch_seconds * 1000000LL;
    has_reference_ = true;
    return true;
}

bool ClockRTC::getTimeAtTicks(uint64_t ticks, int64_t& time_us) {
    if (!has_reference_) return false;

    TickEdgeSample latest;
    if (!sqw_.peek(latest) || latest.seq != ref_seq_ ||
        latest.ticks != ref_ticks_) {
        return false;
    }

    // El PPS consultado puede ser anterior al ultimo SQW porque RMC
    // se valida posteriormente. La hora base SIEMPRE viene del DS3231,
    // leida junto al SQW; solo trasladamos esa lectura al tick pedido.
    const bool despues = ticks >= ref_ticks_;
    const uint64_t distancia_ticks = despues ? (ticks - ref_ticks_)
                                               : (ref_ticks_ - ticks);
    if (distancia_ticks > MAX_EDGE_AGE_TICKS) return false;

    const int64_t delta_us = ticksToUs(distancia_ticks);
    time_us = ref_time_us_ + (despues ? delta_us : -delta_us);
    return true;
}
