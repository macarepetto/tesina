#include <Arduino.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <RTClib.h>
#include "Setup.h"
#include "Json_Log_Builder.h"

static constexpr int32_t MAX_PPS_ERROR_TICKS = 10;

Setup app("esp32-prototipo-1");

bool rtc_aligned = false;
bool kalman_trained = false;
int64_t offset_ticks = 0;
uint32_t last_pps_ms = 0;
uint32_t last_predict_ms = 0;

// Conversion IDENTICA a la utilizada para publicar fechas en el JSON anterior.
static void formatTimeJson(char* out, size_t size, bool ok, int64_t local_us) {
    if (!ok || local_us <= 0) {
        snprintf(out, size, "null");
        return;
    }

    const uint32_t secs = uint32_t(local_us / 1000000LL);
    const uint32_t us = uint32_t(local_us % 1000000LL);
    const DateTime t(secs);

    snprintf(out, size,
        "\"%04u-%02u-%02uT%02u:%02u:%02u.%06lu\"",
        unsigned(t.year()), unsigned(t.month()), unsigned(t.day()),
        unsigned(t.hour()), unsigned(t.minute()), unsigned(t.second()),
        (unsigned long)us);
}

// El builder genera el registro de diagnostico; las tres fechas legibles
// se conservan como campos adicionales en EL MISMO JSON.
// No se agrega un segundo mensaje por PPS ni por HOLDOVER.
static void enviarTresHoras(uint64_t event_ticks,
                            bool rtc_permitido, bool kalman_permitido,
                            JsonLogRecord registro) {
    int64_t gnss = 0, rtc = 0, kalman = 0;
    const bool gnss_ok = app.clockGnss().getTimeAtTicks(event_ticks, gnss);
    const bool rtc_ok = rtc_permitido &&
                        app.clockRtc().getTimeAtTicks(event_ticks, rtc);
    const bool kalman_ok = kalman_permitido &&
                           app.clockKalman().getTimeAtTicks(event_ticks, kalman);

    // Las tres lecturas anteriores usan exactamente el mismo event_ticks.
    registro.clocks.has_ticks = true;
    registro.clocks.ticks = event_ticks;
    registro.clocks.gnss_ok = gnss_ok;
    registro.clocks.gnss_us = gnss;
    registro.clocks.rtc_ok = rtc_ok;
    registro.clocks.rtc_us = rtc;
    registro.clocks.kalman_ok = kalman_ok;
    registro.clocks.kalman_us = kalman;

    // Diagnosticos disponibles al armar el registro, sin nuevas validaciones.
    registro.gps_sats = app.gps().getGgaNumSats();
    registro.gps_pdop = app.gps().getGsaPdop();
    registro.gps_hdop = app.gps().getGgaHdop();
    GpsUtcSample muestra_utc;
    registro.has_utc_validation = true;
    registro.utc_valid = app.gps().getValidatedUtcSample(muestra_utc);

    char json[Telemetry_Queue_Module::JSON_CAPACITY];
    if (!buildLogJson(registro, json, sizeof(json))) return;

    // Mantener los campos gnss/rtc/kalman anteriores, con fecha ISO,
    // sin modificar Json_Log_Builder.h/.cpp enviados por la usuaria.
    char gnss_json[40], rtc_json[40], kalman_json[40];
    formatTimeJson(gnss_json, sizeof(gnss_json), gnss_ok, gnss);
    formatTimeJson(rtc_json, sizeof(rtc_json), rtc_ok, rtc);
    formatTimeJson(kalman_json, sizeof(kalman_json), kalman_ok, kalman);

    const size_t used = strlen(json);
    if (used < 2 || json[used - 1] != '}') return;
    const size_t available = sizeof(json) - (used - 1);
    const int n = snprintf(json + used - 1, available,
        ",\"gnss\":%s,\"rtc\":%s,\"kalman\":%s}",
        gnss_json, rtc_json, kalman_json);
    if (n <= 0 || static_cast<size_t>(n) >= available) return;

    // Mismo mecanismo de telemetria y misma condicion de conexion.
    if (app.wifi().isServerConnected()) {
        app.telemetryQueue().enqueue(json);
    }
}

// Se guarda el PPS mientras llega su RMC posterior.
static bool pps_pendiente = false;
static uint64_t pps_pendiente_ticks = 0;
static uint32_t pps_pendiente_ms = 0;
static bool pps_rtc_permitido = false;
static bool pps_kalman_permitido = false;
static JsonLogRecord pps_registro_pendiente;
static uint32_t holdover_steps = 0;
static bool prediccion_holdover_pendiente = false;

static void publicarPpsPendiente() {
    if (!pps_pendiente) return;
    enviarTresHoras(pps_pendiente_ticks,
                    pps_rtc_permitido, pps_kalman_permitido,
                    pps_registro_pendiente);
    pps_pendiente = false;
}

void setup() {
    app.begin();  // Se conserva el Setup existente.
    Serial.println("Tres relojes: hora del MISMO tick capturado.");
    Serial.println("GNSS solo en PPS con UTC asociada; RTC y Kalman tambien en holdover.");
}

void loop() {
    app.gps().update();
    app.gps().consultarUbxUtcSiCorresponde();
    app.clockRtc().update();  // UNICO consumidor del SQW.

    TickEdgeSample edge;
    if (app.pps().consume(edge)) { // UNICO consumidor del PPS.
        // Cerrar la muestra anterior ANTES de registrar la nueva, de modo
        // que la correccion Kalman guardada siga correspondiendo a esos ticks.
        publicarPpsPendiente();

        last_pps_ms = millis();
        last_predict_ms = last_pps_ms;
        holdover_steps = 0; // Solo contador para diagnostico JSON.
        prediccion_holdover_pendiente = false;
        bool rtc_ajustado_en_este_pps = false;
        bool intervalo_valido = false;
        bool kalman_en_este_pps = false;

        // Se conserva SIN CAMBIOS la inicializacion RTC desde PPS/UTC.
        if (!rtc_aligned) {
            uint64_t prev_ticks = 0;
            int64_t prev_epoch = 0;
            if (app.clockGnss().lastReference(prev_ticks, prev_epoch) &&
                edge.ticks > prev_ticks &&
                edge.ticks - prev_ticks >= 32768ULL - MAX_PPS_ERROR_TICKS &&
                edge.ticks - prev_ticks <= 32768ULL + MAX_PPS_ERROR_TICKS &&
                uint32_t(micros() - edge.at_us) <= 50000UL) {
                const DateTime nextSecond(uint32_t(prev_epoch + 1));
                if (app.rtc().setFromDateTime(nextSecond)) {
                    app.clockRtc().invalidate();
                    app.kalman().reset();
                    app.clockKalman().setReference();
                    offset_ticks = 0;
                    rtc_aligned = true;
                    kalman_trained = false;
                    rtc_ajustado_en_este_pps = true;
                    Serial.println("RTC ajustado una vez en PPS siguiente, con UTC/GNSS validada.");
                }
            }
        } else {
            // Se conservan los mismos criterios de intervalo y ecuaciones Kalman.
            const int64_t error = int64_t(edge.diff) - 32768LL;
            intervalo_valido = edge.valid && edge.seq != 0 &&
                edge.pending == 1 &&
                edge.period_us >= 800000UL && edge.period_us <= 1200000UL &&
                llabs((long long)error) <= MAX_PPS_ERROR_TICKS;
            if (intervalo_valido) {
                offset_ticks += error;
                app.kalman().predict();
                app.kalman().updatePhi(double(offset_ticks));
                kalman_trained = true;
                kalman_en_este_pps = true;
            }
        }

        if (edge.valid && edge.seq != 0 && edge.pending == 1) {
            pps_pendiente = true;
            pps_pendiente_ticks = edge.ticks;
            pps_pendiente_ms = millis();
            // No interpolar a traves de una escritura del calendario DS3231.
            pps_rtc_permitido = !rtc_ajustado_en_este_pps;
            pps_kalman_permitido = rtc_aligned && kalman_trained &&
                                   !rtc_ajustado_en_este_pps;
            // El estado Kalman de ESTE evento se congela antes de esperar RMC.
            app.clockKalman().captureStateAtTicks(edge.ticks);

            // Copiar el evento y el estado de Kalman AHORA, antes de esperar
            // su RMC posterior. No leer el estado de otro PPS al publicar.
            pps_registro_pendiente = JsonLogRecord{};
            pps_registro_pendiente.id = app.deviceId();
            pps_registro_pendiente.tipo = JsonLogType::PPS;
            pps_registro_pendiente.ms = last_pps_ms;
            pps_registro_pendiente.aging = app.agingApplied();
            pps_registro_pendiente.rtc_aligned = rtc_aligned;
            pps_registro_pendiente.kalman_trained = kalman_trained;
            pps_registro_pendiente.has_pps = true;
            pps_registro_pendiente.pps = edge;
            pps_registro_pendiente.interval_valid = intervalo_valido;
            pps_registro_pendiente.has_offset_ticks = rtc_aligned;
            pps_registro_pendiente.offset_ticks = offset_ticks;
            pps_registro_pendiente.kalman_prediccion = kalman_en_este_pps;
            pps_registro_pendiente.kalman_actualizado = kalman_en_este_pps;
            pps_registro_pendiente.has_kalman = kalman_trained;
            if (kalman_trained) {
                pps_registro_pendiente.kalman = app.kalman().getState();
            }
        }
    }

    // La RMC de este PPS llega DESPUES del flanco; GNSS solo usa peek().
    app.clockGnss().update();

    if (pps_pendiente) {
        uint64_t utc_ticks = 0;
        int64_t utc_seconds = 0;
        if (app.clockGnss().lastReference(utc_ticks, utc_seconds) &&
            utc_ticks == pps_pendiente_ticks) {
            publicarPpsPendiente();
        }
        // Si no hubo UTC aceptada, publicar con GNSS=null antes de que
        // la referencia SQW quede demasiado lejos del evento.
        else if (millis() - pps_pendiente_ms > 1000UL) {
            publicarPpsPendiente();
        }
    }

    // Predecir durante perdida de PPS, como en el main anterior.
    const uint32_t ms = millis();
    if (rtc_aligned && ms - last_pps_ms > 1500UL &&
        ms - last_predict_ms >= 1000UL) {
        app.kalman().predict();
        last_predict_ms = ms;
        prediccion_holdover_pendiente = true;
    }

    // Sin PPS no congelamos tampoco el RTC ni Kalman: seguimos
    // tomando UNA muestra de PCNT por segundo, GNSS devuelve null.
    static uint32_t ultimo_holdover_ms = 0;
    if (ms - last_pps_ms > 1500UL &&
        ms - ultimo_holdover_ms >= 1000UL) {
        ultimo_holdover_ms = ms;
        const uint64_t event_ticks = app.pcnt().read();
        ++holdover_steps;
        JsonLogRecord registro;
        registro.id = app.deviceId();
        registro.tipo = JsonLogType::HOLDOVER;
        registro.ms = ms;
        registro.aging = app.agingApplied();
        registro.rtc_aligned = rtc_aligned;
        registro.kalman_trained = kalman_trained;
        registro.has_offset_ticks = rtc_aligned;
        registro.offset_ticks = offset_ticks;
        registro.kalman_prediccion = prediccion_holdover_pendiente;
        registro.kalman_actualizado = false;
        registro.has_kalman = kalman_trained;
        if (kalman_trained) registro.kalman = app.kalman().getState();
        registro.ms_since_last_pps = ms - last_pps_ms;
        registro.holdover_steps = holdover_steps;
        enviarTresHoras(event_ticks, true, rtc_aligned && kalman_trained,
                        registro);
        prediccion_holdover_pendiente = false;
    }

    delay(2);
}
