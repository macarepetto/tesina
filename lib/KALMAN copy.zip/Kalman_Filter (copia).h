#ifndef KALMAN_FILTER_H
#define KALMAN_FILTER_H

#include <Arduino.h>

/*
    Filtro de Kalman para estimar el estado del reloj RTC respecto del PPS GNSS.

    Estado:

        x = [ phi ]
            [  f  ]

    donde:

        phi = offset acumulado estimado
        f   = variación del offset por intervalo PPS (pendiente / deriva)

    Modelo:

        x(k+1) = F x(k) + w(k)

        phi(k+1) = phi(k) + f(k) + w_phi
        f(k+1)   = f(k)        + w_f

        F = [1 1]
            [0 1]

    Ruido del proceso:

        w ~ N(0, Q)

        Q = E[w w^T]

        Q = [ q_phi   0  ]
            [   0    q_f ]

    Medición escalar utilizada en esta versión:

        z = f

        z = H x + v

        H = [0 1]

        v ~ N(0, R)

        R = r_f = sigma_f^2

    En el programa principal, z se obtiene a partir de diff:

        z_f = diff

    offset_ticks se conserva como medición acumulada auxiliar para registro,
    comparación y validación, pero no se usa como segunda medición simultánea
    dentro del filtro.
*/

struct Kalman_Config {
    /*
        Q = [ q_phi   0  ]
            [   0    q_f ]

        q_phi = sigma_phi^2
        q_f   = sigma_f^2

        Representan el ruido del modelo.
    */
    double q_phi = 0.0001;
    double q_f   = 0.0000001;

    /*
        R para medición escalar de f:

            z = f
            H = [0 1]
            R = r_f = sigma_f^2
    */
    double r_f = 0.12;

    /*
        P inicial:

            P = E[e e^T]

        donde:

            e = x_real - x_estimado

        P representa la incertidumbre inicial de la estimación.
    */
    double p_phi_0 = 100.0;
    double p_f_0   = 1.0;
};

struct Kalman_State {
    /*
        Estado estimado:

            x = [ phi ]
                [  f  ]
    */
    double phi = 0.0;
    double f   = 0.0;

    /*
        Matriz de covarianza del error de estimación:

            P = [ p00 p01 ]
                [ p10 p11 ]
    */
    double p00 = 0.0;
    double p01 = 0.0;
    double p10 = 0.0;
    double p11 = 0.0;

    /*
        Innovación de la medición escalar:

            y_f = z_f - f_pred
    */
    double y_f = 0.0;

    /*
        Ganancia de Kalman para medición escalar z = f:

            K = [ k_phi ]
                [ k_f   ]
    */
    double k_phi = 0.0;
    double k_f   = 0.0;
};

class Kalman_Filter {
public:
    explicit Kalman_Filter(const Kalman_Config& config = Kalman_Config());

    void reset(double initial_phi = 0.0, double initial_f = 0.0);

    /*
        Predicción:

            x_pred(k) = F x(k-1)
            P_pred(k) = F P(k-1) F^T + Q
    */
    void predict();

    /*
        Actualización con medición escalar de f:

            z = f
            H = [0 1]
            R = r_f
    */
    void updateF(double z_f);

    Kalman_State getState() const;

private:
    Kalman_Config cfg;

    double phi;
    double f;

    double p00;
    double p01;
    double p10;
    double p11;

    double y_f;
    double k_phi;
    double k_f;
};

#endif
