#include "Kalman_Filter.h"

Kalman_Filter::Kalman_Filter(const Kalman_Config& config)
    : cfg(config) {
    reset();
}

void Kalman_Filter::reset(double initial_phi, double initial_f) {
    /*
        Estado inicial:

            x = [ phi ]
                [  f  ]
    */
    phi = initial_phi;
    f   = initial_f;

    /*
        P inicial:

            P = [ p_phi_0    0    ]
                [    0     p_f_0  ]

        Se arranca con covarianza cruzada cero.
    */
    p00 = cfg.p_phi_0;
    p01 = 0.0;
    p10 = 0.0;
    p11 = cfg.p_f_0;

    y_f = 0.0;

    k_phi = 0.0;
    k_f   = 0.0;
}

void Kalman_Filter::predict() {
    /*
        Modelo:

            x_pred(k) = F x(k-1)

        donde:

            F = [1 1]
                [0 1]

        Entonces:

            phi_pred = phi + f
            f_pred   = f
    */
    const double phi_pred = phi + f;
    const double f_pred   = f;

    phi = phi_pred;
    f   = f_pred;

    /*
        Covarianza:

            P_pred(k) = F P(k-1) F^T + Q

        con:

            P = [ p00 p01 ]
                [ p10 p11 ]

            F = [1 1]
                [0 1]

            Q = [ q_phi  0   ]
                [  0    q_f ]

        Desarrollo:

            p00_pred = p00 + p01 + p10 + p11 + q_phi
            p01_pred = p01 + p11
            p10_pred = p10 + p11
            p11_pred = p11 + q_f
    */
    const double p00_pred = p00 + p01 + p10 + p11 + cfg.q_phi;
    const double p01_pred = p01 + p11;
    const double p10_pred = p10 + p11;
    const double p11_pred = p11 + cfg.q_f;

    p00 = p00_pred;
    p01 = p01_pred;
    p10 = p10_pred;
    p11 = p11_pred;
}

void Kalman_Filter::updateF(double z_f) {
    /*
        Caso de medición escalar:

            z = f
            H = [0 1]
            R = r_f

        Predicción de la medición:

            z_pred = H x_pred
            z_pred = f

        Innovación:

            y = z - z_pred
    */
    const double z_pred = f;
    const double y = z_f - z_pred;

    /*
        S = H P H^T + R

        Como H = [0 1]:

            S = p11 + r_f
    */
    const double S = p11 + cfg.r_f;

    if (S == 0.0) {
        return;
    }

    /*
        K = P H^T S^-1

        Como H = [0 1]:

            K = [ p01 / S ]
                [ p11 / S ]
    */
    const double k0 = p01 / S;
    const double k1 = p11 / S;

    /*
        Actualización del estado:

            x = x_pred + K y
    */
    phi = phi + k0 * y;
    f   = f   + k1 * y;

    /*
        Actualización de P:

            P = (I - K H) P_pred

        con:

            K = [ k0 ]
                [ k1 ]

            H = [0 1]

            I - K H = [1   -k0]
                      [0  1-k1]
    */
    const double old_p00 = p00;
    const double old_p01 = p01;
    const double old_p10 = p10;
    const double old_p11 = p11;

    p00 = old_p00 - k0 * old_p10;
    p01 = old_p01 - k0 * old_p11;
    p10 = (1.0 - k1) * old_p10;
    p11 = (1.0 - k1) * old_p11;

    y_f = y;

    k_phi = k0;
    k_f   = k1;
}

Kalman_State Kalman_Filter::getState() const {
    Kalman_State state;

    state.phi = phi;
    state.f   = f;

    state.p00 = p00;
    state.p01 = p01;
    state.p10 = p10;
    state.p11 = p11;

    state.y_f = y_f;

    state.k_phi = k_phi;
    state.k_f   = k_f;

    return state;
}
